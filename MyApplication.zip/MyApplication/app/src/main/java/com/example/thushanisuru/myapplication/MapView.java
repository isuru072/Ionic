package com.example.thushanisuru.myapplication;

import android.os.Bundle;

/**
 * Created by Thushan Isuru on 9/3/2018.
 */

class MapView {
    public void onCreate(Bundle savedInstanceState) {
    }

    public void onStart() {
    }

    public void onResume() {
    }

    public void onPause() {
    }

    public void onStop() {
    }

    public void onLowMemory() {
    }

    public void onDestroy() {
    }

    public void onSaveInstanceState(Bundle outState) {
    }
}
