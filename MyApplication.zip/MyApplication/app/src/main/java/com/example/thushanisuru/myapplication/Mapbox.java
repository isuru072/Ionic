package com.example.thushanisuru.myapplication;

/**
 * Created by Thushan Isuru on 9/3/2018.
 */

class Mapbox {
    public static void getInstance(MainActivity mainActivity, String s) {
    }
}
